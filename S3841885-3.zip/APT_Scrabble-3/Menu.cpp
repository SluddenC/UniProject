#include "LinkedList.h"
#include "Player.h"
#include "Menu.h"
#include "SaveLoad.h"
#include <iostream>
#include <fstream>
#include <sstream>



Menu::Menu(Board *board, LinkedList *tileBag, std::vector<Player *> players, SaveLoad *sl)
{
    this->board = board;
    this->tileBag = tileBag;
    this->players = players;
    this->sl = sl;

    execMenu();
}

// Print menu, accepting user inputs to perform specific scrabble functions
void Menu::execMenu()
{
    bool menuLoop = true;
    std::cout << "Welcome to Scrabble!" << std::endl;
    std::cout << "-------------------" << std::endl;
    // Loop until condition met
    while (menuLoop)
    {
        std::cout << "Menu" << std::endl;
        std::cout << "----" << std::endl;
        std::cout << "1. New Game" << std::endl;
        std::cout << "2. Load Game" << std::endl;
        std::cout << "3. 3-4 Players "<< std::endl;
        std::cout << "4. Credits (Show student information)" << std::endl;
        std::cout << "5. Quit" << std::endl
                  << std::endl;

        std::cout << "> ";
        std::string command;
        std::getline(std::cin, command);
        std::cout << std::endl;

        // Exit if CTRL+D or 4: Exit program
        if (std::cin.eof() || command == QUIT)
        {
            if (std::cin.eof())
            {
                std::cout << std::endl;
            }
            std::cout << "Goodbye" << std::endl;
            menuLoop = false;
        } else if (command == "help"){
            std::cout << "Enter the number next to an option to choose it" << '\n';
            std::cout << "1 will allow you to start a new scrabble game" << '\n';
            std::cout << "2 will allow you to load a saved scrabble game" << '\n';
            std::cout << "3 will allow you start a scrabble game with 3-4 players" << '\n';
            std::cout << "4 will show the credits" << '\n';
            std::cout << "5 will exit the program" << '\n';
        }
        // If 1: Start game
        else if (command == NEW_GAME)
        {
            std::cout << "Starting a New Game" << std::endl
                      << std::endl;
            // newGame: Shuffle tiles in tilebag and setup player names for each player, startGame: Manage player turns and win condition
            if (!newGame(PLAYERS) && !startGame(0,false))
            {
                menuLoop = false;
            }
            else
            {
                // Exit if CTRL+D
                std::cout << std::endl
                          << "Goodbye" << std::endl;
                menuLoop = false;
            }
        }
        // If 2: Load game
        else if (command == LOAD_GAME)
        {
            // Get filename to load
            std::cout << "Enter the filename from which load a game" << std::endl
                      << "> ";
            std::string fileName;
            std::getline(std::cin, fileName);
            std::cout << std::endl;

            // Exit if CTRL+D
            if (std::cin.eof())
            {
                std::cout << std::endl
                          << "Goodbye" << std::endl;
                menuLoop = false;
            }
            else
            {
                // Get starting player index
                // SaveLoad *sl = new SaveLoad();
                int playerIndex = sl->load(fileName, board, tileBag, players);
                this->numOfPlayers = sl->getPlayerAmount();
                // If valid player index, start the game with player specified
                if (playerIndex >= 0)
                {
                    std::cout << "Scrabble game successfully loaded" << std::endl;
                    if (startGame(playerIndex,true))
                    {
                        std::cout << std::endl
                                  << "Goodbye" << std::endl;
                        menuLoop = false;
                    }
                }
                // Filename has errors
                else
                {
                    std::cout << "Invalid input" << std::endl
                              << std::endl;
                }
            }
        }
        else if (command == MORE_PLAYERS){
            std::cout << "Enter number of players" << std::endl
                      << ">";
            std::string numberOfPlayers;
            std::getline(std::cin, numberOfPlayers);
            std::cout << std::endl;
            if(stoi(numberOfPlayers) < MIN_PLAYERS){
                std::cout << "This mode is for 3-4 players only" << std::endl;
            }else{
               this->numOfPlayers = stoi(numberOfPlayers); 
                 if (!newGame(numOfPlayers) && !startGame(0,false))
            {
                menuLoop = false;
            }
            }
        }
        // If 3: Print credits
        else if (command == CREDITS)
        {
            printCredits();
        }
        // If unrecognised input
        else
        {
            std::cout << "Invalid input" << std::endl << ">";
            
        }
    }
}

bool Menu::newGame(int numberOfplayers)
{
    bool exit = false;
    int playersAdded = 0;
    players.resize(numberOfplayers);
    // While CTRL+D not hit and all player details haven't been set yet
    while (!exit && playersAdded < numberOfplayers)
    {
        // Prompt user for player name
        std::cout << "Enter a name for player " << (playersAdded + 1) << " (uppercase characters only)" << std::endl;
        std::cout << "> ";
        // Get player name as user input
        std::string playerName;
        std::getline(std::cin, playerName);
        std::cout << std::endl;
        // Exit if CTRL+D
        if (std::cin.eof())
        {
            std::cout << std::endl;
            exit = true;
        }
        else
        {
            bool validChars = true;
            // Check if empty input
            if (playerName == "")
            {
                validChars = false;
            }
            // Check all characters of name to see if they are valid (A-Z only)
            for (int i = 0; i < int(playerName.length()); i++)
            {
                if (playerName[i] < LETTER_A || playerName[i] > LETTER_Z)
                {
                    validChars = false;
                }
            }
            // If characters in name are valid
            if (validChars)
            {
                // Set name of player
                players[playersAdded]->setName(playerName);
                // Reset score to 0
                players[playersAdded]->setScore(0);
                // Reset number of passes
                players[playersAdded]->setPasses(0);
                // Reset hand to empty linked list
                players[playersAdded]->setHand(*(new LinkedList));
                // Increment number of players added
                playersAdded++;
            }
            // If invalid input
            else
            {
                std::cout << "Invalid input" << std::endl;
            }
        }
    }
    // Shuffle tilebag
    tileBag->setTileBag(TILE_FILE);

    return exit;
}

bool Menu::startGame(int curPlayer, bool fromLoad)
{
    bool exit = false;
    bool playing = true;
    if(fromLoad == true){
        players.resize(numOfPlayers);
    }
    std::cout << "Let's play!" << std::endl;

    while (!exit && playing)
    {
        if (curPlayer == int(players.size()))
        {
            curPlayer = 0;
        }
        // If tilebag and player hand are empty, end game
        if (tileBag->size() == 0 && players[curPlayer]->getHand().size() == 0)
        {
            playing = false;
        }
        else
        {
            // Take player's turn, exit if EOF char
            if (playerTurn(*players[curPlayer]))
            {
                exit = true;
            }
            else
            {
                // If tilebag is empty and one of [player hand is empty or player has passed 2 or more times], end game
                if (tileBag->size() == 0 && (players[curPlayer]->getHand().size() == 0 || players[curPlayer]->getPasses() >= MAX_PASSES))
                {
                    playing = false;
                }
                else {
                    // Go to next player
                    curPlayer++;
                }
            }
        }
    }

    // Game has finished
    if (!playing)
    {
        board->printBoard();
        std::cout << "Game over" << std::endl;
        // Print score for each player
        for (int i = 0; i < int(players.size()); i++)
        {
            std::cout << "Score for " << players[i]->getName() << ": " << players[i]->getScore() << std::endl;
        }
        // Get players with highest score by removing low scoring ones from players
        for (int i = 0; i < int(players.size()) - 1; i++)
        {
            if (players[i]->getScore() < players[i + 1]->getScore())
            {
                players.erase(players.begin());
            }
            else {
                players.erase(std::next(players.begin()));
            }
        }
        // If there is a singular winner
        if (int(players.size()) == 1)
        {
            std::cout << "Player " << players[0]->getName() << " won!" << std::endl << std::endl;
        }
        // If there is a tie in scores
        else
        {
            std::cout << "Players ";
            for (int i = 0; i < int(players.size()); i++)
            {
                std::cout << players[i]->getName();
                // If not the last player in players, print a comma
                if (i < int(players.size()) - 1)
                {
                    std::cout << ", ";
                }
            }
            std::cout << " drew!" << std::endl;
        }
    }
    return exit;
}

bool Menu::playerTurn(Player &player)
{
    bool exit = false;
    bool getInput = true;
    // Draw from tile bag until 7 tiles in hand or tile bag empty
    player.drawHand(*tileBag);

    // Print player info
    std::cout << player.getName() << ", it's your turn" << std::endl;
    for (int i = 0; i < int(players.size()); i++)
    {
        if(player.getName().size() > 0)
        std::cout << "Score for " << players[i]->getName() << ": " << players[i]->getScore() << std::endl;
    }
    // Print board
    board->printBoard();
    // Print player hand
    std::cout << std::endl
              << "Your hand is" << std::endl;
    player.getHand().printTiles();
    std::cout << std::endl;

    // Vector of tiles to add (via placeTile)
    std::vector<Tile *> tiles;
    std::vector<char> rows;
    std::vector<int> cols;

    // LinkedList of player hand (for backup)
    LinkedList &playerHand = *(new LinkedList(player.getHand()));

    // While CTRL+D not pressed and player's turn has not ended yet
    while (!exit && getInput)
    {
        // Get user input (e.g., place, replace, pass, etc.)
        std::cout << "> ";
        std::string userInput;
        std::getline(std::cin, userInput);
        // Split user input by spaces into vector of strings
        std::vector<std::string> words = splitString(userInput);

        if (std::cin.eof())
        {
            std::cout << std::endl;
            exit = true;
        }
        // Pass
        else if (userInput == "pass")
        {
            // Increment number of passes of player
            player.incrementPasses();
            // Reset hand of player
            player.setHand(playerHand);
            getInput = false;
        }
        // place Done, replace tile, save filename
        else if (words.size() == 2)
        {
            // place Done
            if (userInput == "place Done")
            {
                if (!placeDone(playerHand, player, tiles, rows, cols))
                {
                    std::cout << "Invalid input" << std::endl;
                }
                else
                {
                    getInput = false;
                    std::cout << std::endl;
                }
            }
            // replace tile
            else if (words[0] == "replace")
            {
                if (!replaceTile(player, words[1]))
                {
                    std::cout << "Invalid input" << std::endl;
                }
                else
                {
                    getInput = false;
                }
            }
            // save file
            else if (words[0] == "save")
            {
                sl->save(words[1], players, player.getName(), board, tileBag);
            }
            else
            {
                std::cout << "Invalid input" << std::endl;
            }
        }
        // place tile at location
        else if (words.size() == 4 && words[0] == "place" && words[2] == "at")
        {
            if (!placeTile(player, tiles, rows, cols, words))
            {
                std::cout << "Invalid input" << std::endl;
            }
        } else if(words[0] == "help"){
            std::cout << "To place a tile please type 'place (x) at (letter, number)'" << std::endl;
            std::cout << "e.g 'place A at H7'" << std::endl;
            std::cout << "To end your turn type 'place Done'" << std::endl;
            std::cout << "You can place as many tiles as are in your hand" << std::endl;
            std::cout << "To replace your hand please type replace and a letter in your hand" << std::endl;
            std::cout << "To save the game please type 'save' and the name you want to save as" << std::endl;
            std::cout << "To pass your turn please type 'pass'" << std::endl;
            std::cout << "To exit the game press ctrl+d" << std::endl;
        }
        // If unrecognised input, print Invalid input
        else
        {
            std::cout << "Invalid input" << std::endl;
        }
    }
    clearVectors(tiles, rows, cols);

    return exit;
}

bool Menu::placeTile(Player &player, std::vector<Tile *> &tiles, std::vector<char> &rows, std::vector<int> &cols, std::vector<std::string> instructions)
{
    bool placed = false;
    bool validLoc = false;

    try
    {
        char letter = instructions[1].at(0);
        char row = instructions[3].at(0);
        int col = stoi(instructions[3].substr(1));

        // If letter is between A-Z
        // AND If row is between A-O (may change depending on dimensions of board)
        // AND If col is between 0-14 (may change depending on dimensions of board)
        if ((LETTER_A <= letter && letter <= LETTER_Z) && (LETTER_A <= row && row <= LETTER_A + MAX_BOARD_SIZE - 1) && (0 <= col && col <= MAX_BOARD_SIZE - 1))
        {
            // If board is empty and tiles is empty, the first tile MUST belong to either the middle row or middle col (H or 7 per scrabble rules on a 15x15 board)
            if (board->isEmpty() && int(tiles.size()) == 0)
            {
                if (row == char(LETTER_A + MAX_BOARD_SIZE / 2))
                {
                    validLoc = true;
                }
                if (col == MAX_BOARD_SIZE / 2)
                {
                    validLoc = true;
                }
            }

            // If tiles is empty
            if (int(tiles.size()) == 0)
            {
                // If location on board is vacant
                if (board->getTile(row, col)->getLetter() == ' ')
                {
                    validLoc = true;
                }
            }
            // If second tile being placed, must have either the same row or col as the first tile
            if (int(tiles.size()) == 1)
            {
                // If location on board is vacant
                if (board->getTile(row, col)->getLetter() == ' ')
                {
                    // If same row as first tile
                    if (row == rows[0])
                    {
                        validLoc = true;
                    }
                    // If same col as first tile
                    if (col == cols[0])
                    {
                        validLoc = true;
                    }
                }
            }
            // If third or greater tile, must match rules of the previous 2 tiles (same row or same col)
            else if (int(tiles.size()) > 1)
            {
                // If location on board is vacant
                if (board->getTile(row, col)->getLetter() == ' ')
                {
                    // If same row
                    if (rows[0] == rows[1])
                    {
                        if (rows[0] == row)
                        {
                            validLoc = true;
                        }
                    }
                    // If same col
                    if (cols[0] == cols[1])
                    {
                        if (cols[0] == col)
                        {
                            validLoc = true;
                        }
                    }
                }
            }

            // Clear vectors if not validLoc
            if (!validLoc)
            {
                clearVectors(tiles, rows, cols);
            }

            // Check if coord is occupied
            bool occupied = false;
            // Check within current place instructions
            for (int i = 0; i < int(tiles.size()); i++)
            {
                if (rows[i] == row && cols[i] == col)
                {
                    occupied = true;
                }
            }
            // Check board
            if (!board->emptyLoc(row, col))
            {
                occupied = true;
            }

            // Check if tile in player hand
            bool inHand = player.getHand().find(letter);

            // Clear hand if tiles doesn't exist
            if (!inHand)
            {
                clearVectors(tiles, rows, cols);
            }

            // If tile location isn't occupied and tile exists in hand
            if (!occupied && inHand && validLoc)
            {
                // Insert values into tiles, rows, cols
                tiles.push_back(new Tile(letter, player.getHand().getTile(letter)->getValue()));
                rows.push_back(row);
                cols.push_back(col);
                // Remove from hand
                player.getHand().remove(letter);
                placed = true;
            }
        }
    }
    catch (...)
    {
    }
    return placed;
}

bool Menu::placeDone(LinkedList &backupHand, Player &player, std::vector<Tile *> &tiles, std::vector<char> &rows, std::vector<int> &cols)
{
    bool placed = false;

    // If a tile has been played
    if (int(tiles.size()) > 0)
    {
        // Attempt to place tiles to board, if successful return true
        if (board->placeTiles(tiles, rows, cols))
        {
            // If 7 tiles were played this turn, bingo
            if (int(tiles.size()) == MAX_HAND_SIZE)
            {
                std::cout << "BINGO!!!" << std::endl
                          << std::endl;
                // Add 50 to player score
                player.setScore(player.getScore() + BINGO_BONUS);
            }
            // Add score of each of the tiles played to okater
            for (int i = 0; i < int(tiles.size()); i++)
            {
                player.setScore(player.getScore() + tiles[i]->getValue());
            }
            placed = true;
        }
        // If issues with placing on board, revert hand and board
        else
        {
            // Revert player hand
            player.setHand(backupHand);
            // Revert board
            for (int i = 0; i < int(tiles.size()); i++)
            {
                board->setTile(new Tile(' ', -1), rows[i], cols[i]);
            }
            // Clear tiles, rows & cols
            clearVectors(tiles, rows, cols);
        }
    }
    if (!placed)
    {
        // Revert player hand
        player.setHand(backupHand);
        // Revert board
        for (int i = 0; i < int(tiles.size()); i++)
        {
            board->setTile(new Tile(' ', -1), rows[i], cols[i]);
        }
        clearVectors(tiles, rows, cols);
    }

    return placed;
}

bool Menu::replaceTile(Player &player, std::string instructions)
{
    bool replaced = false;
    if (instructions.length() == 1)
    {
        // Get letter from input
        char letter = instructions.at(0);
        // Get and remove tile from player hand if it exists, nullptr otherwise
        Tile *tile = player.getHand().remove(letter);
        // If tile exists, add tile to end of tile bag, then fill player's hand up to 7 if possible
        if (tile != nullptr)
        {
            tileBag->add_back(tile);
            player.drawHand(*tileBag);
            replaced = true;
        }
    }
    // True if tile replaced
    return replaced;
}

void Menu::printCredits()
{
    // Print student details
    std::cout << "----------------------------------" << std::endl;
    std::cout << "Name: Wilson Luc" << std::endl;
    std::cout << "Student ID: s3858342" << std::endl;
    std::cout << "Email: s3858342@student.rmit.edu.au" << std::endl
              << std::endl;

    std::cout << "Name: Leon Ngo" << std::endl;
    std::cout << "Student ID: s3813566" << std::endl;
    std::cout << "Email: s3813566@student.rmit.edu.au" << std::endl
              << std::endl;

    std::cout << "Name: Shanelle Morais" << std::endl;
    std::cout << "Student ID: s3826525" << std::endl;
    std::cout << "Email: s3826525@student.rmit.edu.au" << std::endl
              << std::endl;

    std::cout << "Name: Callum Sludden" << std::endl;
    std::cout << "Student ID: s3841885" << std::endl;
    std::cout << "Email: s3841885@student.rmit.edu.au" << std::endl;
    std::cout << "----------------------------------" << std::endl
              << std::endl;
}

std::vector<std::string> Menu::splitString(std::string str)
{
    std::string tempString;
    // Read string in like cin
    std::stringstream ss(str);
    std::vector<std::string> words;
    // For every word split by space, push into words
    while (getline(ss, tempString, ' '))
    {
        words.push_back(tempString);
    }
    return words;
}

// Method to clear vectors
void Menu::clearVectors(std::vector<Tile *> tiles, std::vector<char> rows, std::vector<int> cols){
    tiles.clear();
    rows.clear();
    cols.clear();
}