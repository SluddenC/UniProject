#ifndef ASSIGN2_LINKEDLIST_H
#define ASSIGN2_LINKEDLIST_H


#include "Node.h"
#include "Tile.h"
#include "Board.h"
#include <string>
#include "Types.h"

class LinkedList {
public:

   LinkedList();
   LinkedList(LinkedList& other);
   ~LinkedList();

   int size();

   Node get(int index);
   void setTileBag(std::string fileName);

   void add_front(Tile* data);
   void add_back(Tile* data);

   void remove_front();
   void remove_back();

   void remove(int index);
   bool find(Letter letter);
   Tile* remove(Letter letter);
   Tile* getTile(Letter letter);

   void clear();
   std::string getTiles();
   void printTiles();

private:
   Node* head;
};

#endif // ASSIGN2_LINKEDLIST_H