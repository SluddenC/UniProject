#include "Tile.h"
#include <iostream>


Tile::Tile(){
   letter = ' ';
   value = -1;
}

Tile::Tile(Letter letter){
   this->letter = letter;
   value = -1;
}


Tile::Tile(Letter letter, Value value)
{
   this->letter = letter;
   this->value = value;
}

Tile::Tile(Letter letter, Value value,int col, char row){
   this->letter = letter;
   this->value = value;
   this->row = row;
   this->col = col;

}

Tile::Tile(Tile& other) {
   this->letter = other.letter;
   this->value = other.value;
}

Tile::~Tile() {
}

Letter Tile::getLetter() {
   return letter;
}

Value Tile::getValue() {
   return value;
}

int Tile::getRow(){
   return row;
}
char Tile::getCol(){
   return col;
}
