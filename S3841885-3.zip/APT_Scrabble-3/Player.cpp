#include "Player.h"
#include <string>
#include <iostream>
#include "LinkedList.h"



//Default constructor with no parameters for the Player class
Player::Player(){
    //Sets all the varibles of Player to default values
    name = "";
    score = 0;
    passes = 0;
    //Creates a new linkedlist called hand
    hand = *(new LinkedList());
}

//Overloaded Player constructor taking a string
Player::Player(std::string name){
    //Sets the name of the Player passed to the constructor and defaults the other variables to their default
    this->name = name;
    score = 0;
    passes = 0;
    hand = *(new LinkedList());
}
//Overloaded Player constructor taking three arguments
Player::Player(std::string name, int score, LinkedList &hand){
    //Sets the variables of Player to those passed to the constructor.
    this->name = name;
    this->score = score;
    this->hand = hand;
}
//Overloaded constructor that takes another Player class as an argument.
Player::Player(Player &other){
    //Sets the varibles to that of the other Player class.
    this->name = other.getName();
    this->score = other.getScore();
    this->passes = other.getPasses();
    //Creates a new linkedlist
    this->hand = *(new LinkedList());
    //Loops through the hand of the passed Player and adds the tiles to the current Player hand.
    for (int i = 0; i < other.getHand().size(); i++){
        Tile* newTile = new Tile(other.getHand().get(i).tile->getLetter(), other.getHand().get(i).tile->getValue());
        this->hand.add_back(newTile);
    }
}
//Deconstructor
Player::~Player(){
    
}
//Method to set the name of the Player returns a bool that is true if the name is valid
bool Player::setName(std::string name){
    // Set boolean to true
    bool validName = true;
    //If the passed string is empty retun false
    if (name == ""){
        validName = false;
    }
    //Loops through each character in the passed string and if one is a space or a non-alphabet character return false
    for (char c : name){
        if (!(LETTER_A <= c && c <= LETTER_Z) || c == ' '){
            validName = false;
        }
    }
    //If the bool is true then set the name of the player to the passed string
    if (validName){
        this->name = name;
    }
    //Return the boolean
    return validName;
}
//Returns the name of the player
std::string Player::getName(){
    return name;
}
//Set the score of the player from passed integer
void Player::setScore(int score){
    this->score = score;
}
//Returns the score of the player
int Player::getScore(){
    return score;
}
//Set the hand of the player from passed linkedlist
void Player::setHand(LinkedList &hand){
    //Clear anything in the current hand
    this->hand.clear();
    //Get the size of the passed hand
    int handSize = hand.size();
    //loops through each item in the passed hand
    for (int i = 0; i < handSize; i++){
        //Sets a tile with the letter and number from the current location in the passed hand
        Tile* newTile = new Tile(hand.get(i).tile->getLetter(), hand.get(i).tile->getValue());
        //std::cout << newTile->getLetter() << std::endl;
        //Add the tile to the current hand
        this->hand.add_back(newTile);
    }
}
//Returns tiles in the hand
LinkedList& Player::getHand(){
    return hand;
}
//Add one to the total passes when a player passes their turn
void Player::incrementPasses(){
    passes++;
}
//Set how many passes a player has used
void Player::setPasses(int numPasses){
    passes = numPasses;
}
//Get the amount of passes a player has used
int Player::getPasses(){
    return passes;
}
//Draws the hand from the tile bag
void Player::drawHand(LinkedList &bag){
    //While the players hand is less than its max size and the tile bag still has tiles in it
    while (hand.size() < MAX_HAND_SIZE && bag.size() > 0){
        //Tile *frontBag = bag.get(0).tile;
        //Gets the first tile from the tile bag and sets it to a tile
        Tile* tempTile = new Tile(bag.get(0).tile->getLetter(), bag.get(0).tile->getValue());
        //std::cout << frontBag->getLetter() << std::endl;
        //Add the tile to the hand
        hand.add_back(tempTile);
        //Remove the tile from the bag
        bag.remove_front();
    }
}

