#ifndef ASSIGN2_BOARD_H
#define ASSIGN2_BOARD_H


#include "Tile.h"
#include <vector>
#include <string>
#include "Types.h"
class Board
{
public:
    Board();
    ~Board();
    std::string getBoard();
    void printBoard();
    void clear();
    char indexToChar(int index);
    int charToIndex(char character);
    std::vector<std::vector<Tile*>> board; 
    bool placeFirstWord(std::vector<Tile*> tiles, std::vector<char> rows, std::vector<int> cols);
    bool placeNthWord(std::vector<Tile*> tiles, std::vector<char> rows, std::vector<int> cols);
    bool checkAdjacent(int row, int col);
    bool placeTiles(std::vector<Tile*> tiles, std::vector<char> rows, std::vector<int> cols);
    bool checkWord(std::vector<Tile*> tiles, std::vector<char> rows, std::vector<int> cols, bool isFirstWord);
    bool validateWord(std::string word);
    bool emptyLoc(char row, int col);

    bool isEmpty();
    bool isLine(std::vector<char> &rows, std::vector<int> &cols);

    void setTile(Tile* tile, char row, int col);
    Tile* getTile(char row, int col);
    bool checkAllAdjacency();

    void resetBoard();
};

#endif // ASSIGN2_BOARD_H