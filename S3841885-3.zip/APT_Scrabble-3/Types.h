#define EXIT_SUCCESS 0
#define MAX_HAND_SIZE 7
#define CHAR 6
#define PLAYERS 2
#define MAX_PLAYERS 4

//board
#define BOARD_SIZE 15
#define LETTER_A 'A'
#define DOUBLE_DIGIT 10
#define EMPTY_STRING ' '

//menu
#define MAX_BOARD_SIZE 15
#define MAX_PASSES 2
#define MAX_HAND_SIZE 7
#define LETTER_A 'A'
#define LETTER_Z 'Z'
#define EMPTY_STRING ' '
#define BINGO_BONUS 50
#define DIVIDER_CHAR '-'
#define BORDER_CHAR '|'

//player
#define MAX_HAND_SIZE 7
#define LETTER_A 'A'
#define LETTER_Z 'Z'

//saveload
#define PLAYER_ELEMENTS 3
#define CELL_PADDING 4
#define MAX_BOARD_SIZE 15
#define MAX_PASSES 2
#define MAX_HAND_SIZE 7
#define LETTER_A 'A'
#define LETTER_Z 'Z'
#define EMPTY_STRING ' '
#define BINGO_BONUS 50
#define DIVIDER_CHAR '-'
#define BORDER_CHAR '|'

//global type define