
#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include "Board.h"

// Constructor for board creation
Board::Board(){
    // For loop that creates a board of 15x15 and adds empty tiles via pushback
    for (int row = 0; row < BOARD_SIZE; row++){
        std::vector<Tile*> boardRow;
        for (int col = 0; col < BOARD_SIZE; col++){
            boardRow.push_back(new Tile());
        }
        board.push_back(boardRow);
    }
}

// Deconstructor for board
Board::~Board(){
    clear();
}

// Returns the board as a string
std::string Board::getBoard(){
    std::string totalBoard;

    // Sets column in board printing
    for (int col = 0; col < BOARD_SIZE; col++){
        //Spaces at the start of first line
        if (col == 0){
            totalBoard += "     ";
        }
        else if (col < DOUBLE_DIGIT){
            totalBoard += " ";
        }
        totalBoard += std::to_string(col);
        totalBoard += "  ";
    }
    totalBoard += "\n";
    
    // Adds a line of dashes
    for (int i = 0; i <= BOARD_SIZE; i++){
        totalBoard += "----";
    }
    totalBoard += "\n";

    // Further formatting for the board
    for (int row = 0; row < BOARD_SIZE; row++){
        totalBoard += " ";
        totalBoard += indexToChar(row);
        totalBoard += " |";
        for (int col = 0; col < BOARD_SIZE; col++){
            totalBoard += " ";
            totalBoard += board[row][col]->getLetter();
            totalBoard += " |";
        }
        if (row < BOARD_SIZE - 1){
            totalBoard += "\n";
        }
    }
    return totalBoard;
}

// Prints the string from getBoard function
void Board::printBoard(){
    std::cout << getBoard() << std::endl;;
}

// Returns a char based on decimal index
char Board::indexToChar(int index){
    return LETTER_A + index;
}

// Returns a decimal index based on the char
int Board::charToIndex(char character){
    return int(character) - int(LETTER_A);
}

// Boolean that checks whether board is empty
bool Board::isEmpty(){
    bool empty = (board[BOARD_SIZE/2][BOARD_SIZE/2])->getLetter() == EMPTY_STRING;
    return empty;
}

// Boolean that checks for empty board at specific location
bool Board::emptyLoc(char row, int col){
    bool empty = false;
    if (board[charToIndex(row)][col]->getLetter() == EMPTY_STRING){
        empty = true;
    }
    return empty;
}

// Method for placing the first word
bool Board::placeFirstWord(std::vector<Tile*> tiles, std::vector<char> rows, std::vector<int> cols){
    bool valid = true;
    std::sort(rows.begin(), rows.end());
    std::sort(cols.begin(), cols.end());

    // Adjacency check
    int numRows = rows.size();
    for (int i = 0; i < numRows - 1; i++){
        if (rows[i]+1 != rows[i+1] && cols[i]+1 != cols[i+1]){
            valid = false;
        }
    }

    // For loop to add tiles to board
    if (valid){
        for (int i = 0; i < numRows; i++){
            int row = charToIndex(rows[i]);
            int col = cols[i];

            board[row][col] = tiles[i];
        }
    }else{
        valid = false;
    }
    return valid;
}

// Method to add 2nd tile onwards
bool Board::placeNthWord(std::vector<Tile*> tiles, std::vector<char> rows, std::vector<int> cols){
    bool validAdj = false;
    bool validBoard = true;

    // Number of tiles in tiles
    int numTiles = tiles.size();
    // Check to see whether at least one of the tiles is adjacent to a tile in board
    for (int i = 0; i < numTiles; i++){
        int row = (charToIndex(rows[i]));
        int col = cols[i];
        if (!validAdj){
            validAdj = checkAdjacent(row, col);
        }
    }

    bool sameRow = true;
    bool sameCol = true;

    // See if the word is horizontal or vertical
    if (numTiles > 1){
        if (rows[0] != rows[1]){
            sameRow = false;
        }
        if (cols[0] != cols[1]){
            sameCol = false;
        }
    }

    if (validAdj){
        // Fill the board
        for (int i = 0; i < numTiles; i++){
            int row = charToIndex(rows[i]);
            int col = cols[i];

            board[row][col] = new Tile(tiles[i]->getLetter(), -1);
        }

        // Check if there are any empty tiles between the word (row)
        if (sameRow){
            // Sort cols
            std::vector<int> sortedCols = cols;
            std::sort(sortedCols.begin(), sortedCols.end());
            for (int i = 0; i < numTiles - 1; i++){
                int row = charToIndex(rows[0]);
                int col = sortedCols[i];

                // Check tile to the right
                if (board[row][col + 1]->getLetter() == ' '){
                    validBoard = false;
                }
            }
        }
        // Check if there are any empty tiles between the word (col)
        if (sameCol){
            // Sort rows
            std::vector<char> sortedRows = rows;
            std::sort(sortedRows.begin(), sortedRows.end());
            for (int i = 0; i < numTiles - 1; i++){
                int row = charToIndex(rows[i]);
                int col = cols[0];

                // Check tile under
                if (board[row+1][col]->getLetter() == ' '){
                    validBoard = false;
                }
            }
        }
    }

    // If no tiles are adjacent to tiles in the original board or blank tiles are found in the middle of the word, revert board
    if (!(validAdj && validBoard)){
        for (int i = 0; i < numTiles; i++){
            int row = charToIndex(rows[i]);
            int col = cols[i];

            board[row][col] = new Tile(' ', -1);
        }
    }
    
    // Return whether or not the word was added
    return validAdj && validBoard;
}

// Adjacency check method
bool Board::checkAdjacent(int row, int col){
    bool found = false;

    // Check above
    if (row != 0 && !found){
        found = (board[row-1][col]->getLetter() != EMPTY_STRING);
    }
    // Check below
    if (row != BOARD_SIZE - 1 && !found){
        found = (board[row+1][col]->getLetter() != EMPTY_STRING);
    }
    // Check left
    if (col != 0 && !found){
        found = (board[row][col-1]->getLetter() != EMPTY_STRING);
    }
    // Check right
    if (col != BOARD_SIZE - 1 && !found){
        found = (board[row][col+1]->getLetter() != EMPTY_STRING);
    }
    return found;
}

// Method to check validity of tiles at specific row or col
bool Board::placeTiles(std::vector<Tile*> tiles, std::vector<char> rows, std::vector<int> cols){
    bool validPos = false;
    bool isAdj = false;
    
    int numTiles = tiles.size();

    if (isEmpty()){
        for (int i = 0; i < numTiles; i++){
            int row = charToIndex(rows[i]);
            int col = cols[i];
            if (row == BOARD_SIZE/2 && col == BOARD_SIZE/2){
                validPos = true;
                isAdj = placeFirstWord(tiles, rows, cols);
            }
        }
    }
    else {
        validPos = true;
        isAdj = placeNthWord(tiles, rows, cols);
    }
    
    return validPos && isAdj;
}

bool Board::checkWord(std::vector<Tile*> tiles, std::vector<char> rows, std::vector<int> cols, bool isFirstWord){
     std::string word;
     int validWord = false;
    std::vector<Tile* > tempTiles;
    if(isFirstWord == true){
        int wordSize = tiles.size();
        for(int i=0; i < wordSize; i++){
           
            tempTiles.push_back(new Tile(tiles[i]->getLetter(),tiles[i]->getValue(), cols[i], rows[i]));    
        }  
     for(int i=0; i < wordSize;i++){
         //std::cout << tempTiles[i]->getCol();
         char letter = tempTiles[i]->getLetter();
         word.push_back(letter);
     }
     if(validateWord(word)){
         validWord=true;
     }
    }

   return validWord;
}

   
    
bool Board::validateWord(std::string word){
    std::vector<std::string> wordlist;
    bool valid = false;
    std::ifstream file("words.txt");
    if(!file){
        std::cout << "words could not be found";
    }
    std::string currentWord;
    while(std::getline(file,currentWord)){
        if(currentWord.size() > 0){
            std::transform(currentWord.begin(),currentWord.end(),currentWord.begin(), ::toupper);
            wordlist.push_back(currentWord);
        }
    }
    file.close();
    for(int i=0; i < wordlist.size(); i++){
        if(wordlist[i].compare(word) == 0){
            valid = true;
        }
    
    }
    if(valid == false){
        std::cout << "Not a valid word" << std::endl;
    }
    return valid;
}
// Method to set the tile on board at specific row or col
void Board::setTile(Tile* tile, char row, int col){
    board[charToIndex(row)][col] = tile;
}

// Method to clear the board
void Board::clear(){
    // Delete all tiles from board
    for (int row = 0; row < BOARD_SIZE; row++){
        for (int col = 0; col < BOARD_SIZE; col++){
            delete board[row][col];
        }
    }
}

// Method to get a tile at a specific row or col
Tile* Board::getTile(char row, int col){
    return board[charToIndex(row)][col];
}

// Method for all adjacencies on board
bool Board::checkAllAdjacency(){
    bool adjacency = true;
    bool middle = false;

    if (board[BOARD_SIZE/2][BOARD_SIZE/2]->getLetter() != ' ' || isEmpty()){
        middle = true;
    }

    int elements = 0;
    for (int i = 0; i < BOARD_SIZE; i++){
        for (int j = 0; j < BOARD_SIZE; j++){
            if (board[i][j]->getLetter() != ' '){
                elements++;
            }
        }
    }

    if (elements > 1){
        for (int i = 0; i < BOARD_SIZE; i++){
            for (int j = 0; j < BOARD_SIZE; j++){
                if (board[i][j]->getLetter() != ' '){
                    if (adjacency){
                        adjacency = checkAdjacent(i, j);
                    }
                }
            }
        }
    }
    return adjacency && middle;
}

// Method to reset board state
void Board::resetBoard(){
    for (int i = 0; i < BOARD_SIZE; i++){
        for (int j = 0; j < BOARD_SIZE; j++){
            setTile(new Tile(' ', -1), indexToChar(i), j);
        }
    }
}