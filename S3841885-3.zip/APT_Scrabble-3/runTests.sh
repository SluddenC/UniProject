#! /bin/bash

fileFolder=testCases

declare -a files
for file in $(find testCases -name '*.input') ; do
    fileName=${file%".input"}
    eval ./scrabble <$fileName.input >$fileName.output
    # diff $fileFolder/$file.expout $fileFolder/$file.out
done