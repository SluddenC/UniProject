#include "LinkedList.h"

#include <iostream>
#include <stdexcept>
#include <fstream>
#include <random>
#include <algorithm>
#include <vector>


LinkedList::LinkedList() {
   head = nullptr;
}

LinkedList::LinkedList(LinkedList& other){
    head = nullptr;
    for (int i = 0; i < other.size(); i++){
        Tile* newTile = new Tile(other.get(i).tile->getLetter(), other.get(i).tile->getValue());
        add_back(newTile);
    }
}

LinkedList::~LinkedList() {
   clear();
}


int LinkedList::size(){
    int length = 0;

    Node* current = head;
    while(current != nullptr){
        ++length;
        current = current->next;
    }
    return length;
}

// Method to add node to the front of the linkedlist
void LinkedList::add_front(Tile* data){
    Node* node = new Node(data, nullptr);
    node->tile = data;
    node->next = head;
    head = node;
}

// Method to add node to the back of the linkedlist
void LinkedList::add_back(Tile* data){
    Node* node = new Node(data, nullptr);
    node->tile = data;
    node->next = nullptr;

    if(head == nullptr){
        head = node;
    }else{
        Node* current = head;
        while(current->next != nullptr){
            current = current->next;
        }
        current->next = node;
    }
}

// Method to remove node from the front of the linkedlist
void LinkedList::remove_front(){
    if(head != nullptr){
        Node* toDelete = head;
        head = head->next;

        delete toDelete->tile;
        delete toDelete;
    }else{
        throw std::runtime_error("Nothing to remove");
    }
}

// Method to remove node from the back of the linkedlist
void LinkedList::remove_back(){
    
    if(head != nullptr){
        Node* current = head;
        //pre should point to node before current;
        Node* prev = nullptr;

        while(current->next != nullptr){
            prev = current;
            current = current->next;
        }

        if(prev == nullptr){
            head = nullptr;
        }else{
            prev->next = nullptr;
        }

        delete current->tile;
        delete current;
    }
}

// Method to remove node at a specific index
void LinkedList::remove(int index){
    if(index >= 0 && index < size()){
        if(head != nullptr){
            int counter = 0;
            Node* current = head;
            //pre should point to node before current;
            Node* prev = nullptr;

            while(counter != index){
                ++counter;
                prev = current;
                current = current->next;
            }

            if(prev == nullptr){
                head = current->next;
            }else{
                prev->next = current->next;
            }

            delete current->tile;
            delete current;
        }
    }
}

// Method to clear linkedlist of nodes
void LinkedList::clear(){
    while(head != nullptr){
        remove_front();
    }
}

// Method to get node from linkedlist at a specific index
Node LinkedList::get(int index){
    Node* curNode = head;
    for (int i = 0; i < index; i++){
        curNode = curNode->next;
    }
    return *curNode;
}

// Method to get a list of tiles
std::string LinkedList::getTiles(){
    std::string totalString;

    Node* curNode = head;

    std::string output;

    // While node is not a null pointer, iterate and create string of tiles
    while (curNode != nullptr){
        Tile* curTile = curNode->tile;
        totalString += curTile->getLetter();
        totalString += "-";
        totalString += std::to_string(curTile->getValue());

        if (curNode->next != nullptr){
            totalString += ", ";
        }
        curNode = curNode->next;
    }
    return totalString;
}

// Method to print get tiles method
void LinkedList::printTiles(){
    std::cout << getTiles();
    std::cout << std::endl;
}

// Method to find a letter tile in linkedlist
bool LinkedList::find(Letter letter){
    Node* curNode = head;
    bool found = false;

    while (curNode != nullptr && !found){
        if (curNode->tile->getLetter() == letter){
            found = true;
        }
        else {
            curNode = curNode->next;
        }
    }
    return found;
}

// Method to get a specific tile object via a letter
Tile* LinkedList::getTile(Letter letter){
    Node* curNode = head;
    Tile* tile = nullptr;

    while (curNode != nullptr && tile == nullptr){
        if (curNode->tile->getLetter() == letter){
            tile = curNode->tile;
        }
        else {
            curNode = curNode->next;
        }
    }
    return tile;
}

// Method to set a tilebag from a save file
void LinkedList::setTileBag(std::string fileName){
    std::vector<std::string> fileLines;

    std::ifstream inFile(fileName);
    std::string line;
    while (std::getline(inFile, line)){
        fileLines.push_back(line);
    }
    
    std::srand(time(NULL));
    std::random_shuffle(fileLines.begin(), fileLines.end());

    clear();
    for (std::string line : fileLines){
        char letter = line[0];
        int value = std::stoi(line.substr(2));

        Tile *curTile = new Tile(letter, value);
        add_back(curTile);
    }
}

// Method to remove a tile from linkedlist
Tile* LinkedList::remove(char character){
    Tile* curTile = nullptr;
    Node* current = head;

    // Check if head tile is character
    if (current->tile->getLetter() == character){
        curTile = head->tile;
        head = head->next;
    }
    else{
        bool loop = true;
        while (loop){
            if (current->next == nullptr){
                loop = false;
            }
            // Valid
            else if (current->next->tile->getLetter() == character){
                curTile = current->next->tile;
                current->next = current->next->next;
                loop = false;
            }
            current = current->next;
        }
    }
    return curTile;
}