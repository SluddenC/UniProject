
#ifndef ASSIGN2_MENU_H
#define ASSIGN2_MENU_H


#include "Board.h"
#include "LinkedList.h"
#include "Player.h"
#include "SaveLoad.h"
#include <string>
#include <vector>
#include "Types.h"

class Menu {
public:

    Menu(Board* board, LinkedList* tileBag, std::vector<Player*> players, SaveLoad* sl);
    void execMenu();
    bool newGame(int numberOfplayers);
    bool startGame(int startingPlayer, bool fromLoad);
    bool playerTurn(Player &player);

    bool placeTile(Player &player, std::vector<Tile*> &tiles, std::vector<char> &rows, std::vector<int> &cols, std::vector<std::string> instuctions);
    bool placeDone(LinkedList &backupHand, Player &player, std::vector<Tile*> &tiles, std::vector<char> &rows, std::vector<int> &cols);
    bool replaceTile(Player &player, std::string instructions);
    void save(std::string fileName, std::vector<Player*> players, std::string name, Board *board, LinkedList *tileBag);

    void printCredits();
    void clearVectors(std::vector<Tile *> tiles, std::vector<char> rows, std::vector<int> cols);
    int load(std::string fileName, Board *board, LinkedList *tileBag, std::vector<Player*> players);

    std::vector<std::string> splitString(std::string str);
private:
    Board* board;
    LinkedList* tileBag;
    SaveLoad* sl;
    std::vector<Player*> players;
    int numOfPlayers;
    const std::string NEW_GAME = "1";
    const std::string LOAD_GAME = "2";
    const std::string MORE_PLAYERS = "3";
    const int MIN_PLAYERS = 3;
    const std::string CREDITS = "4";
    const std::string QUIT = "5";
    const std::string TILE_FILE = "ScrabbleTiles.txt";
};

#endif // ASSIGN2_MENU_H