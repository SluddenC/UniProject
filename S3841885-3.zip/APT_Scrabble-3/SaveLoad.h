#ifndef ASSIGN2_SAVELOAD_H
#define ASSIGN2_SAVELOAD_H


#include "Board.h"
#include "LinkedList.h"
#include "Player.h"
#include <string>
#include <vector>
#include "Types.h"
class SaveLoad
{
public:
    SaveLoad();
    ~SaveLoad();
    int load(std::string fileName, Board *board, LinkedList *tileBag, std::vector<Player *> players);
    void save(std::string fileName, std::vector<Player *> players, std::string name, Board *board, LinkedList *tileBag);
    int getPlayerAmount();
    private:
    int numOfPlayers;
};

#endif // ASSIGN2_SAVELOAD_H