#include "SaveLoad.h"
#include "LinkedList.h"
#include "Player.h"
#include "Menu.h"

#include <iostream>
#include <fstream>
#include <sstream>

SaveLoad::SaveLoad(){
}

SaveLoad::~SaveLoad(){}

int SaveLoad::load(std::string fileName, Board *board, LinkedList *tileBag, std::vector<Player*> players){
    int playerIndex = -1;
    bool valid = true;
    int lineNum = 0;
    std::string line;
    std::vector<char> letters;
    std::vector<char> rows;
    std::vector<int> cols;
    int amtPlayers = 0;
    // Stream of data from file input
    std::ifstream file(fileName);
    // If file doesn't exist
    if (!file.good()){
        valid = false;
    }
     
    // If file exists
    else {
         std::getline(file, line);
            amtPlayers = std::stoi(line);
            this->numOfPlayers = amtPlayers;
             players.resize(amtPlayers);
             file.clear();
            file.seekg(0, std::ios::beg); 
        // Count number of lines in file
        while (std::getline(file, line)){
            lineNum++;
        }       
        // If number of lines doesn't match expected, end load
        if (lineNum != PLAYER_ELEMENTS*int(players.size()) + MAX_BOARD_SIZE + 2 + 2 + 1){
          std::cout << lineNum;
            valid = false;
        }

        // Reset ifstream
        file.clear();
        file.seekg(0, std::ios::beg); 
    }
        
    // Iterate through file
    lineNum = 0;
    int i = 0;
    char rowCounter = LETTER_A;
     std::getline(file, line);
    while (std::getline(file, line) && valid){
        // If reading in player name, score and hand
        if(i <= amtPlayers+1){
        if (lineNum < PLAYER_ELEMENTS*int(players.size())){
            // Store current player in variable
          
            Player *player = players[int(lineNum/PLAYER_ELEMENTS)];
            // If player name or score are empty, end loop
            if (lineNum % PLAYER_ELEMENTS == 0 || lineNum % PLAYER_ELEMENTS == 1){
                if (line.empty()){
                    valid = false;
                }
            }
            // Attempt to set player name
            if (lineNum % PLAYER_ELEMENTS == 0){
                if (!player->setName(line)){
                    valid = false;
                }
            }
            // Attempt to set score (if >= 0)
            if (lineNum % PLAYER_ELEMENTS == 1){
                try {
                    int score = stoi(line);
                    if (score >= 0){
                        player->setScore(score);
                    }
                    else {
                        valid = false;
                    }
                }
                catch (...){
                    valid = false;
                }
            }
            // Attempt to set player hands
            if (lineNum % PLAYER_ELEMENTS == 2){
                // Clear player hand
                player->getHand().clear();
                // If hand isn't empty, attempt to populate 
                int commaCount = 0;

                if (!line.empty()){
                    try {
                        // Split line by ',' char
                        std::string delim = ", ";
                        while (line.find(delim) != std::string::npos){
                            commaCount++;
                            std::string tile = line.substr(0, line.find(delim));
                            line.erase(0, line.find(delim) + delim.length());

                            // Get letter and value from substring of line
                            char letter = tile.substr(0, 1)[0];
                            int value = std::stoi(tile.substr(2));
                            // Check if letter between A-Z
                            if (letter < LETTER_A || letter > LETTER_Z){
                                valid = false;
                            }
                            // Value can't be negative or 0
                            if (letter <= 0){
                                valid = false;
                            }
                        
                            // Push line as tile to player hand
                            player->getHand().add_back(new Tile(letter, value));
                        }
                        // Push final line as tile to player hand
                        player->getHand().add_back(new Tile(line.substr(0, 1)[0], std::stoi(line.substr(2))));
                    }
                    catch (...){
                        valid = false;
                    }
                }
                // If there are more than 7 tiles in hand at time of load
                if (commaCount >= MAX_HAND_SIZE){
                    valid = false;
                }                
            }
         } i++; }
        // Set board (+2 required because there is a column header + divider)
        else if (PLAYER_ELEMENTS*int(players.size()) <= lineNum && lineNum < PLAYER_ELEMENTS*int(players.size()) + MAX_BOARD_SIZE + 2){
            // Check length of lines for board
            if (line.length() != (MAX_BOARD_SIZE+1)*4){
                valid = false;
            }
            // Check header
            if (lineNum == PLAYER_ELEMENTS*int(players.size())){
                int colCounter = 0;
                // Iterate through line
                for (int i = 0; i < int(line.length()); i++){
                    if (i > CELL_PADDING && i % CELL_PADDING == 1){
                        try {
                            // If position of header cannot be converted to an int or doesn't match expected column name, valid is false
                            if (stoi(line.substr(i-1, CELL_PADDING)) != colCounter){
                                valid = false;
                            }
                        }
                        catch (...) {

                        }
                        colCounter++;
                    }
                }
                // If first 4 characters are not whitespaces, then valid is false
                if (line.substr(0, CELL_PADDING) != std::string(4, EMPTY_STRING)){
                    valid = false;
                }
            }
            // Check divider
            if (lineNum == PLAYER_ELEMENTS*int(players.size()) + 1){
                for (int i = 0; i < int(line.length()); i++){
                    // If expected char isn't '-', valid is false
                    if (line.at(i) != DIVIDER_CHAR){
                        valid = false;
                    }
                }
            }
            // Check cell contents
            if (PLAYER_ELEMENTS*int(players.size()) + 2 <= lineNum && lineNum <= PLAYER_ELEMENTS*int(players.size()) + 2 + MAX_BOARD_SIZE){
                // Iterate through lines where there are table cells
                for (int i = 0; i < int(line.length()); i++){
                    // If index in line is meant to be whitespace only
                    if (i%CELL_PADDING == 2 || i%CELL_PADDING == 4){
                        if (line.at(i) != EMPTY_STRING){
                            valid = false;
                        }
                    }
                    // If index in line is meant to be a '|' char only
                    else if (i%CELL_PADDING == 3){
                        if (line.at(i) != BORDER_CHAR){
                            valid = false;
                        }
                    }
                    else if (i%CELL_PADDING == 1){
                        // If row label is expected value
                        if (i < CELL_PADDING - 1){
                            if (line.at(1) != rowCounter){
                                valid = false;
                            }
                        }
                        // If index in line can be a whitespace or letter from A-Z
                        else {
                            if (line.at(i) != EMPTY_STRING && (LETTER_A <= line.at(i) && line.at(i) <= LETTER_Z)){
                                letters.push_back(line.at(i));
                                rows.push_back(rowCounter);
                                cols.push_back(i/CELL_PADDING - 1);
                            }
                            else if (line.at(i) != EMPTY_STRING && (line.at(i) < LETTER_A || line.at(i) > LETTER_Z)){
                                valid = false;
                            }
                        }
                    }
                }
                // Increment row label
                rowCounter++;
            }
        }
        // Check tilebag
        if (lineNum == PLAYER_ELEMENTS*int(players.size()) + 2 + MAX_BOARD_SIZE){
            if (!line.empty()){
                try {
                    // Split line by delim
                    std::string delim = ", ";

                    while (line.find(delim) != std::string::npos){
                        std::string tile = line.substr(0, line.find(delim));
                        line.erase(0, line.find(delim) + delim.length());

                        char letter = tile.substr(0, 1)[0];
                        int value = std::stoi(tile.substr(2));
                        // Check if letter between A-Z
                        if (letter < LETTER_A || letter > LETTER_Z){
                            valid = false;
                        }
                        // Value can't be negative or 0
                        if (letter <= 0){
                            valid = false;
                        }
                        
                        // Push line as tile to tile bag
                        tileBag->add_back(new Tile(letter, value));
                    }
                    // Push final line as tile to tile bag
                    tileBag->add_back(new Tile(line.substr(0, 1)[0], std::stoi(line.substr(2))));
                }
                catch (...){
                    valid = false;
                }
            }
            else {
                valid = false;
            }
        }
        // Check player turn
        if (lineNum == PLAYER_ELEMENTS*int(players.size()) + 2 + MAX_BOARD_SIZE + 1){
            // Check if line is empty
            if (!line.empty()){
                bool found = false;
                // Iterate through every player
                for (int i = 0; i < int(players.size()); i++){
                    // If player name matches line name, set found to true
                    if (players[i]->getName() == line){
                        // Set playerIndex
                        playerIndex = i;
                        found = true;
                    }
                }
                // If line name not found, valid is false
                if (!found){
                    valid = false;
                }
            }
            else {
                // If empty, valid is false
                valid = false;
            }
        }
        lineNum++;
    }

    if (valid){
        for (int i = 0; i < int(letters.size()); i++){
            board->setTile(new Tile(letters[i], -1), rows[i], cols[i]);
        }
        
        // Check adjacency for whole board
        valid = board->checkAllAdjacency();
    }

    // Clear board if any passes fail
    if (!valid){
        playerIndex = -1;
        // Reset player hands and board
        for (int i = 0; i < int(players.size()); i++){
            players[i]->getHand().clear();
        }
        board->resetBoard();
    }

    letters.clear();
    rows.clear();
    cols.clear();

    return playerIndex;
}

void SaveLoad::save(std::string fileName, std::vector<Player*> players, std::string name, Board *board, LinkedList *tileBag){
    // Write to fileName (overwrite)
    std::ofstream myFile(fileName, std::ofstream::trunc);
    myFile << players.size() << std::endl;
    for (int i = 0; i < int(players.size()); i++){
        // Write player name
        myFile << players[i]->getName() << std::endl;
        // Write player score
        myFile << players[i]->getScore() << std::endl;
        // Write player hand
        myFile << players[i]->getHand().getTiles() << std::endl;
    }

    // Write board state
    myFile << board->getBoard() << std::endl;
    // Write tile bag
    myFile << tileBag->getTiles() << std::endl;
    // Write current player name
    myFile << name << std::endl;

    // Close file
    myFile.close();    

    // Print save successful
    std::cout << std::endl;
    std::cout << "Game successfully saved" << std::endl;
    std::cout << std::endl;
}
int SaveLoad::getPlayerAmount(){
    return numOfPlayers;
}