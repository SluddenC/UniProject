#ifndef ASSIGN2_PLAYER_H
#define ASSIGN2_PLAYER_H


#include <string>
#include "LinkedList.h"
#include "Types.h"

class Player {
public:
   Player();
   Player(std::string name);
   Player(std::string name, int score, LinkedList &hand);
   Player(Player &other);

   ~Player();

   bool setName(std::string name);

   std::string getName();

   void setScore(int score);

   int getScore();

   void setHand(LinkedList &hand);

   LinkedList& getHand();

   void incrementPasses();

   void setPasses(int numPasses);

   int getPasses();

   void drawHand(LinkedList &bag);


private:
   std::string    name;
   int            score;
   LinkedList     hand; 
   int            passes;
};

#endif // ASSIGN2_PLAYER_H