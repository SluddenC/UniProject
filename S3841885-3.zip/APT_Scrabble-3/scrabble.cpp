#include "Menu.h"

#include <ctime>
#include <iostream>
#include <fstream>
#include <random>
#include <algorithm>

int main(void){
    Board *board = new Board();
    LinkedList *tileBag = new LinkedList();
    SaveLoad *sl = new SaveLoad();
    std::vector<Player*> players;
    for (int i = 0; i < MAX_PLAYERS; i++){
        players.push_back(new Player());
    }

    Menu(board, tileBag, players, sl);
 
    delete board;
    delete tileBag;
    delete sl;
    
    for (int i = 0; i < MAX_PLAYERS; i++){
        delete players[i];
    }
    return EXIT_SUCCESS;
}